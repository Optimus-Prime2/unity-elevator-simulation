using UnityEngine;

// This script manages multiple elevators.
// When a floor button is pressed, it selects the closest available elevator.

public class ElevatorManager : MonoBehaviour
{
    public Elevator[] elevators; // Array containing references to all elevators in the scene

    public void RequestElevator(int floorNumber)
    {
        Elevator closest = null;
        int smallest = int.MaxValue;

        for (int i = 0; i < elevators.Length; i++)
        {
            if (elevators[i].isMoving) // skip elevators that are already moving
                continue;

            int dist = Mathf.Abs(elevators[i].currentFloor - floorNumber);

            if (dist < smallest)  // Find the elevator with the smallest distance from the requested floor
            {
                smallest = dist;
                closest = elevators[i];
            }
        }

        if (closest != null)
        {
            closest.MoveToFloor(floorNumber);
        }
    }
}
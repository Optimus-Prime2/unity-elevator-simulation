using UnityEngine;
using System.Collections;


public class Elevator : MonoBehaviour
{
    public bool isMoving = false;
    public int currentFloor = 0;
    public float speed = 1f;

    public float[] floorHeights = { -4f, -1f, 2f, 5f };

    public void MoveToFloor(int floorNumber)
    {
        if (isMoving) return;
        StopAllCoroutines();
        StartCoroutine(MoveElevator(floorNumber)); // start moving the elevator toward the requested floor.
    }

    IEnumerator MoveElevator(int floorNumber)
    {
        isMoving = true; // mark elevator as busy
        float targetY = floorHeights[floorNumber];

        while (Mathf.Abs(transform.position.y - targetY) > 0.01f) // Gradually move the elevator toward the target floor each frame
        {
            float newY = Mathf.MoveTowards(
                transform.position.y,
                targetY,
                speed * Time.deltaTime
            );

            transform.position = new Vector3(
                transform.position.x,
                newY,
                transform.position.z
            );

            yield return null;
        }

        transform.position = new Vector3(
            transform.position.x,
            targetY,
            transform.position.z
        );

        currentFloor = floorNumber; // update the elevator's current floor after reaching the destination.

        isMoving = false; // elevator becomes available again
    }
}
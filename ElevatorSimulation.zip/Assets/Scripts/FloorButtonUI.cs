using UnityEngine;

public class FloorButtonUI : MonoBehaviour
{
    public int floorNumber;
    public ElevatorManager manager;

    public void PressButton()
    {
        manager.RequestElevator(floorNumber);
    }
}